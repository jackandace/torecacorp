import type {ImgHTMLAttributes} from 'react';
type Props=ImgHTMLAttributes<HTMLImageElement>&{fill?:boolean;priority?:boolean};
export default function StaticImage({fill,priority,style,...props}:Props){return <img {...props} loading={priority?'eager':props.loading??'lazy'} style={{...(fill?{position:'absolute',height:'100%',width:'100%',inset:0}:{}),...style}}/>}
